1. Have a few different screens in script that do their own thing well.
2. Append section
3. Remove section
4. Activity section
5. copy section
