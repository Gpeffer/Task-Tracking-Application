Requirements-

1. list tasks
2. remove tasks
3. assign a date and time to tasks
4. assign a due date to tasks
5. mark tasks as complete
6.
7.
8.
9.
10.
